
import React, { useState, useEffect } from 'react';
import { User, Quiz, QuizAttempt } from '../types';
import { db, collection, query, where, orderBy, onSnapshot, getDocs } from '../services/firebase';

interface StudentPortalProps {
  user: User;
  onStartQuiz: (quiz: Quiz) => void;
}

const StudentPortal: React.FC<StudentPortalProps> = ({ user, onStartQuiz }) => {
  const [code, setCode] = useState('');
  const [availableQuizzes, setAvailableQuizzes] = useState<Quiz[]>([]);
  const [history, setHistory] = useState<QuizAttempt[]>([]);
  const [activeView, setActiveView] = useState<'quizzes' | 'history'>('quizzes');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch active quizzes
    const qQuizzes = query(collection(db, 'quizzes'), where('isActive', '==', true), orderBy('createdAt', 'desc'));
    const unsubscribeQuizzes = onSnapshot(qQuizzes, (snapshot) => {
      setAvailableQuizzes(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Quiz)));
      setLoading(false);
    });

    // Fetch student's history
    const qHistory = query(
      collection(db, 'attempts'), 
      where('className', '==', user.className), 
      where('seatNumber', '==', user.seatNumber),
      orderBy('timestamp', 'desc')
    );
    const unsubscribeHistory = onSnapshot(qHistory, (snapshot) => {
      setHistory(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as QuizAttempt)));
    });

    return () => {
      unsubscribeQuizzes();
      unsubscribeHistory();
    };
  }, [user.className, user.seatNumber]);

  const handleJoin = async () => {
    if (!code) return;
    const q = query(collection(db, 'quizzes'), where('code', '==', code.toUpperCase()));
    const snap = await getDocs(q);
    
    if (!snap.empty) {
      setError('');
      onStartQuiz({ id: snap.docs[0].id, ...snap.docs[0].data() } as Quiz);
    } else {
      setError('找不到此測驗代碼，請確認後再試。');
    }
  };

  return (
    <div className="animate-fadeIn max-w-6xl mx-auto">
      <header className="mb-12 flex flex-col md:flex-row justify-between items-end gap-8">
        <div>
          <div className="flex items-center gap-3 mb-3">
            <span className="bg-indigo-600 text-white text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-[0.2em] shadow-lg shadow-indigo-100">
              Student Profile
            </span>
          </div>
          <h1 className="text-5xl font-black text-slate-900 tracking-tighter">
            你好，{user.name}
          </h1>
          <p className="text-slate-400 font-bold mt-2 uppercase text-xs tracking-widest">
            {user.className} ・ 座號 {user.seatNumber}
          </p>
        </div>

        <div className="flex bg-white p-2 rounded-[2rem] border border-slate-200 shadow-xl shadow-slate-100">
          <button 
            onClick={() => setActiveView('quizzes')}
            className={`px-10 py-3 rounded-[1.5rem] text-sm font-black transition-all ${activeView === 'quizzes' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-400 hover:bg-slate-50'}`}
          >
            進行中
          </button>
          <button 
            onClick={() => setActiveView('history')}
            className={`px-10 py-3 rounded-[1.5rem] text-sm font-black transition-all ${activeView === 'history' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-400 hover:bg-slate-50'}`}
          >
            歷史紀錄
          </button>
        </div>
      </header>

      {activeView === 'quizzes' ? (
        <div className="grid lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 space-y-8">
            <div className="grid md:grid-cols-2 gap-6">
              {loading ? (
                <div className="col-span-2 py-20 text-center text-slate-300 font-black italic animate-pulse">SYNCHRONIZING CLOUD DATA...</div>
              ) : availableQuizzes.length === 0 ? (
                <div className="col-span-2 bg-white border-4 border-dashed border-slate-100 rounded-[3rem] p-24 text-center">
                  <p className="text-slate-300 font-black text-2xl italic">NO ASSIGNMENTS AVAILABLE</p>
                </div>
              ) : (
                availableQuizzes.map(quiz => (
                  <div key={quiz.id} className="bg-white p-10 rounded-[3rem] shadow-sm border border-slate-100 hover:shadow-2xl hover:border-indigo-100 transition-all group flex flex-col justify-between relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50/50 rounded-bl-[4rem] -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-700"></div>
                    <div className="relative z-10">
                      <div className="flex justify-between items-start mb-6">
                        <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center font-black text-xl border border-indigo-100 shadow-sm">
                          {quiz.questions.length}
                        </div>
                        <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest bg-indigo-50/50 px-3 py-1 rounded-full">Active</span>
                      </div>
                      <h3 className="text-2xl font-black text-slate-900 mb-3 leading-tight tracking-tight italic">{quiz.title}</h3>
                      <p className="text-sm text-slate-400 font-medium mb-10 line-clamp-2">{quiz.description || '點擊下方按鈕開始此測驗。'}</p>
                    </div>
                    <button 
                      onClick={() => onStartQuiz(quiz)}
                      className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black hover:bg-indigo-600 transition-all transform active:scale-95 shadow-xl hover:shadow-indigo-100 relative z-10"
                    >
                      TAKE CHALLENGE
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          <aside className="space-y-8">
            <div className="bg-indigo-600 p-10 rounded-[3rem] text-white shadow-2xl shadow-indigo-100 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -mr-20 -mt-20 blur-2xl group-hover:scale-150 transition-transform duration-1000"></div>
              <h3 className="text-2xl font-black mb-4 italic tracking-tight">快速進入</h3>
              <p className="text-indigo-100 text-sm mb-8 font-bold uppercase tracking-widest text-[10px]">Enter specific quiz code</p>
              <div className="space-y-4 relative z-10">
                <input 
                  type="text" 
                  value={code}
                  onChange={e => setCode(e.target.value.toUpperCase())}
                  placeholder="EX: A1B2C3"
                  maxLength={6}
                  className="w-full bg-white/10 border-2 border-white/20 px-6 py-4 rounded-2xl placeholder:text-white/30 focus:bg-white focus:text-slate-900 transition-all outline-none font-mono text-center tracking-[0.3em] font-black text-xl"
                />
                {error && <p className="text-red-200 text-xs text-center font-black animate-bounce">{error}</p>}
                <button 
                  onClick={handleJoin}
                  className="w-full py-5 bg-white text-indigo-600 rounded-2xl font-black shadow-xl hover:bg-slate-50 transition-all transform active:scale-95"
                >
                  ENTER
                </button>
              </div>
            </div>

            <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm">
              <h4 className="font-black text-slate-900 italic text-xl mb-6">今日公告</h4>
              <ul className="space-y-6">
                <li className="flex gap-4">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 flex-shrink-0 animate-pulse"></div>
                  <p className="text-slate-500 text-sm font-medium"><span className="font-black text-slate-900">交卷檢查：</span>雲端系統會自動儲存，請確認答案無誤後提交。</p>
                </li>
                <li className="flex gap-4">
                  <div className="w-2 h-2 bg-amber-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-slate-500 text-sm font-medium"><span className="font-black text-slate-900">網路連線：</span>若測驗中斷，重新登入即可恢復。</p>
                </li>
              </ul>
            </div>
          </aside>
        </div>
      ) : (
        <div className="bg-white rounded-[4rem] border border-slate-100 shadow-xl shadow-slate-100 overflow-hidden animate-fadeIn">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50 border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">
              <tr>
                <th className="px-10 py-6">Assignment Title</th>
                <th className="px-10 py-6">Date</th>
                <th className="px-10 py-6 text-center">Score</th>
                <th className="px-10 py-6 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {history.length > 0 ? history.map(h => {
                const ratio = h.score / h.totalQuestions;
                const statusColor = ratio >= 0.8 ? 'text-emerald-500 bg-emerald-50 border-emerald-100' : ratio >= 0.6 ? 'text-amber-500 bg-amber-50 border-amber-100' : 'text-red-500 bg-red-50 border-red-100';
                return (
                  <tr key={h.id} className="hover:bg-indigo-50/20 transition-colors">
                    <td className="px-10 py-8">
                      <p className="font-black text-slate-900 text-xl italic tracking-tight">{h.quizTitle}</p>
                      <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">{h.totalQuestions} Questions Total</p>
                    </td>
                    <td className="px-10 py-8 text-sm font-black text-slate-400">
                      {new Date(h.timestamp).toLocaleDateString()}
                    </td>
                    <td className="px-10 py-8 text-center">
                      <span className="text-3xl font-black text-slate-900 tracking-tighter">{h.score}</span>
                      <span className="text-slate-200 text-sm mx-1">/</span>
                      <span className="text-sm font-black text-slate-300">{h.totalQuestions}</span>
                    </td>
                    <td className="px-10 py-8 text-center">
                      <span className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border shadow-sm ${statusColor}`}>
                        {ratio >= 0.8 ? 'EXCELLENT' : ratio >= 0.6 ? 'PASSED' : 'RETAKE'}
                      </span>
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={4} className="px-10 py-32 text-center text-slate-300 font-black italic text-xl">
                    HISTORY IS EMPTY
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default StudentPortal;
