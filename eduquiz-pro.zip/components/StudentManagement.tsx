
import React, { useState, useEffect } from 'react';
import { RegisteredStudent } from '../types';
import { db, collection, addDoc, deleteDoc, doc, onSnapshot, query, orderBy, setDoc } from '../services/firebase';

const StudentManagement: React.FC = () => {
  const [students, setStudents] = useState<RegisteredStudent[]>([]);
  const [newStudent, setNewStudent] = useState({ className: '', seatNumber: '', name: '' });
  const [importText, setImportText] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'students'), orderBy('className'), orderBy('seatNumber'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as RegisteredStudent));
      setStudents(list);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleAdd = async () => {
    if (!newStudent.className || !newStudent.seatNumber || !newStudent.name) return;
    try {
      await addDoc(collection(db, 'students'), newStudent);
      setNewStudent({ ...newStudent, seatNumber: (parseInt(newStudent.seatNumber) + 1).toString(), name: '' });
    } catch (err) {
      console.error("Add failed", err);
    }
  };

  const handleBatchImport = async () => {
    const lines = importText.split('\n');
    const batch = [];
    lines.forEach(line => {
      const parts = line.split(/[,\t ]+/);
      if (parts.length >= 3) {
        batch.push({
          className: parts[0].trim(),
          seatNumber: parts[1].trim(),
          name: parts[2].trim()
        });
      }
    });

    for (const s of batch) {
      await addDoc(collection(db, 'students'), s);
    }
    setImportText('');
  };

  const handleDelete = async (id: string) => {
    await deleteDoc(doc(db, 'students', id));
  };

  const classes = Array.from(new Set(students.map(s => s.className))).sort();

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="grid md:grid-cols-2 gap-6">
        <section className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
            <svg className="w-5 h-5 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4" />
            </svg>
            新增單一學生
          </h3>
          <div className="grid grid-cols-3 gap-2 mb-4">
            <input 
              type="text" placeholder="班級" value={newStudent.className}
              onChange={e => setNewStudent({...newStudent, className: e.target.value})}
              className="px-4 py-3 bg-slate-50 border-0 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
            />
            <input 
              type="text" placeholder="座號" value={newStudent.seatNumber}
              onChange={e => setNewStudent({...newStudent, seatNumber: e.target.value})}
              className="px-4 py-3 bg-slate-50 border-0 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
            />
            <input 
              type="text" placeholder="姓名" value={newStudent.name}
              onChange={e => setNewStudent({...newStudent, name: e.target.value})}
              className="px-4 py-3 bg-slate-50 border-0 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>
          <button onClick={handleAdd} className="w-full py-3 bg-slate-900 text-white rounded-xl text-sm font-black hover:bg-indigo-600 transition-all">新增學生</button>
        </section>

        <section className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-lg mb-4 flex items-center gap-2 text-emerald-600">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            批量匯入名單
          </h3>
          <textarea 
            placeholder="班級 座號 姓名 (可用空白或逗號分隔)"
            value={importText}
            onChange={e => setImportText(e.target.value)}
            className="w-full h-24 px-4 py-3 bg-slate-50 border-0 rounded-xl text-xs mb-4 resize-none focus:ring-2 focus:ring-emerald-500 outline-none"
          />
          <button onClick={handleBatchImport} className="w-full py-3 bg-emerald-600 text-white rounded-xl text-sm font-black hover:bg-emerald-700 transition-all">執行匯入</button>
        </section>
      </div>

      <section className="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-8 py-5 border-b bg-slate-50/50 flex justify-between items-center">
          <h3 className="font-black text-slate-800 tracking-tight">已匯入名單 ({students.length})</h3>
          <div className="flex gap-2">
            {classes.map(c => (
              <span key={c} className="text-[10px] bg-white border border-slate-200 px-3 py-1 rounded-full font-black text-slate-500 shadow-sm">{c}</span>
            ))}
          </div>
        </div>
        <div className="max-h-[500px] overflow-y-auto">
          {loading ? (
            <div className="p-12 text-center text-slate-400 font-bold italic animate-pulse">名單讀取中...</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50/50 text-slate-400 font-black uppercase text-[10px] tracking-widest sticky top-0 backdrop-blur-sm">
                <tr>
                  <th className="px-8 py-4 text-left">班級</th>
                  <th className="px-8 py-4 text-left">座號</th>
                  <th className="px-8 py-4 text-left">姓名</th>
                  <th className="px-8 py-4 text-right">管理</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {students.map(s => (
                  <tr key={s.id} className="hover:bg-indigo-50/30 transition-colors group">
                    <td className="px-8 py-4 font-black text-slate-900">{s.className}</td>
                    <td className="px-8 py-4 text-slate-600 font-bold">{s.seatNumber}</td>
                    <td className="px-8 py-4 text-slate-600 font-bold">{s.name}</td>
                    <td className="px-8 py-4 text-right">
                      <button onClick={() => handleDelete(s.id)} className="text-slate-300 hover:text-red-500 p-2 transition-colors">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </td>
                  </tr>
                ))}
                {students.length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-8 py-20 text-center text-slate-300 font-bold italic">尚無學生名單，請先匯入</td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </div>
  );
};

export default StudentManagement;
